﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace pr16_4_KM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Dictionary<string, int> country = new Dictionary<string, int>();
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string mess = "";
            bool res = true;

            if (textBox1.Text != string.Empty)
            {
                string file = textBox1.Text;

                if (File.Exists(file))
                {
                    string[] lines = File.ReadAllLines(file);

                    foreach (var line in lines)
                    {
                        var parts = line.Split(new char[] { ' ' }, 2);
                        if (parts.Length == 2)
                        {
                            if (int.TryParse(parts[1].Replace(" ", ""), out int popul))
                            {
                                if (!country.ContainsKey(parts[0]))
                                {
                                    country.Add(parts[0], popul);
                                }
                                else
                                {
                                    mess = $"Страна {parts[0]} уже существует.";
                                    res = false;
                                    break;
                                }
                            }
                            else
                            {
                                mess = "Неправильно записано число";
                                res = false;
                                break;
                            }
                        }
                        else
                        {
                            mess = "Лишние данные";
                            res = false;
                            break;
                        }
                    }

                    if (res == true)
                    {
                        listBox1.Items.Clear();

                        foreach (var item in country)
                        {
                            listBox1.Items.Add($"{item.Key} {item.Value}");
                        }

                        mess = "Данные внесены";
                    }
                }
                else
                {
                    mess = "Нет такого файла";
                }
            }
            else
            {
                mess = "Заполните поле Название файла";
            }

            MessageBox.Show(mess);

            Country.Enabled = true;
            label1.Enabled = true;
            button1.Enabled = true;
            numericUpDown1.Enabled = true;
            numericUpDown2.Enabled = true;
            button2.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var mess = "";

            int n = (int)numericUpDown2.Value;

            var filteredCountries = country
                        .Where(c => c.Value > n)
                        .OrderBy(c => c.Key.Length)
                        .ThenBy(c => c.Key)
                        .ToList();

            listBox2.Items.Clear();

            foreach (var item in filteredCountries)
            {
                listBox2.Items.Add($"{item.Key} {item.Value}");
            }

            mess = "Данные внесены";

            MessageBox.Show(mess);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var mess = "";
            
            if (Country.Text == string.Empty)
            {
                mess = "Заполните поле Страна";
            }
            else
            {
                string country_new = Country.Text;
                int n = (int)numericUpDown1.Value;

                country.Add(country_new, n);

                listBox1.Items.Clear();
                
                foreach (var item in country)
                {
                    listBox1.Items.Add($"{item.Key} {item.Value}");
                }
            }

            MessageBox.Show(mess);
        }
    }
}
